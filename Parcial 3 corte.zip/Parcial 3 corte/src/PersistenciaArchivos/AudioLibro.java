/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package PersistenciaArchivos;

import java.awt.HeadlessException;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.StringJoiner;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author LEONARDO ACUÑA
 */
public class AudioLibro implements Ilibro{
    protected String idbn;
    protected String titulo;
    protected String autor;
    protected String anio;
    protected String costo;
    private String nPaginas;
    private String edicion;
    private String duracion,formato,peso;

    public String getPeso() {
        return peso;
    }

    public void setPeso(String peso) {
        this.peso = peso;
    }

    public String getDuracion() {
        return duracion;
    }

    public void setDuracion(String duracion) {
        this.duracion = duracion;
    }

    public String getFormato() {
        return formato;
    }

    public void setFormato(String formato) {
        this.formato = formato;
    }
    
    public String getIdbn() {
        return idbn;
    }

    public void setIdbn(String idbn) {
        this.idbn = idbn;
    }

    public String getTitulo() {
        return titulo;
    }

    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }

    public String getAutor() {
        return autor;
    }

    public void setAutor(String autor) {
        this.autor = autor;
    }

    public String getAnio() {
        return anio;
    }

    public void setAnio(String anio) {
        this.anio = anio;
    }

    public String getCosto() {
        return costo;
    }

    public void setCosto(String costo) {
        this.costo = costo;
    }

    public String getnPaginas() {
        return nPaginas;
    }

    public void setnPaginas(String nPaginas) {
        this.nPaginas = nPaginas;
    }

    public String getEdicion() {
        return edicion;
    }

    public void setEdicion(String edicion) {
        this.edicion = edicion;
    }

    @Override
    public void crearArchivo() {
        try
        {
            File objetoArchivo = new File("AudioLibro.txt");
            if (objetoArchivo.createNewFile())
            {
                JOptionPane.showMessageDialog(null, "Se ha creado correctamenteo el archivo" + objetoArchivo.getName());
            } else
            {
                JOptionPane.showMessageDialog(null, "El archivo ya existe");
            }

        } catch (Exception e)
        {
            System.out.println("Ocurrio un error al crear el archivo");

        }
    }

    @Override
    public void agregarRegistros() {
        try
        {
            FileWriter fw = new FileWriter("AudioLibro.txt", true);
            fw.write(getIdbn());
            fw.write(",");
            fw.write(getTitulo());
            fw.write(",");
            fw.write(getAutor());
            fw.write(",");
            fw.write(getAnio());
            fw.write(",");
            fw.write(getCosto());
            fw.write(",");
            fw.write(getnPaginas());
            fw.write(",");
            fw.write(getEdicion());
            fw.write(",");
            fw.write(getDuracion());
            fw.write(",");
            fw.write(getFormato());
            fw.write(",");
            fw.write(getPeso());
            fw.write("\n");
            fw.close();

            JOptionPane.showMessageDialog(null, "Se registro correctamente");
        } catch (HeadlessException | IOException e)
        {
            JOptionPane.showMessageDialog(null, "Ocurrio un error al registrar" + e.toString());
        }
    }

    @Override
    public void MostrarTotal(JTable tablaTotalLibros) {

        String nombreArchivo = "AudioLibro.txt";

        File file = new File(nombreArchivo);

        try
        {

            BufferedReader br = new BufferedReader(new FileReader(file));

            String primeraLinea = br.readLine().trim();

            DefaultTableModel model = new DefaultTableModel();

            model.addColumn("IDBN");
            model.addColumn("TITULO");
            model.addColumn("AUTOR");
            model.addColumn("AÑO");
            model.addColumn("COSTO");
            model.addColumn("PAGINAS");
            model.addColumn("EDICION");
            model.addColumn("DURACION");
            model.addColumn("FORMATO");
            model.addColumn("PESO");
            tablaTotalLibros.setModel(model);

            Object[] tableLines = br.lines().toArray();

            for (Object tableLine : tableLines)
            {
                String line = tableLine.toString().trim();
                String[] datarow = line.split(",");
                model.addRow(datarow);
                tablaTotalLibros.setModel(model);
            }

        } catch (IOException e)
        {
            JOptionPane.showMessageDialog(null, "Ocurrio un error" + e.toString());

        }
    }
    public void seleccionar(JTable tablaLibros) {

        try
        {

            int fila = tablaLibros.getSelectedRow();

            if (fila >= 0)
            {

                setIdbn(tablaLibros.getValueAt(fila, 0).toString());
                setTitulo(tablaLibros.getValueAt(fila, 1).toString());
                setAnio(tablaLibros.getValueAt(fila, 2).toString());
                setCosto(tablaLibros.getValueAt(fila, 3).toString());
                setnPaginas(tablaLibros.getValueAt(fila, 4).toString());
                setEdicion(tablaLibros.getValueAt(fila, 5).toString());
                setDuracion(tablaLibros.getValueAt(fila, 6).toString());
                setFormato(tablaLibros.getValueAt(fila, 7).toString());
                setPeso(tablaLibros.getValueAt(fila, 8).toString());
            }

        } catch (Exception e)
        {
            JOptionPane.showMessageDialog(null, "Ocurrio un error" + e.toString());
        }

    }
    
    @Override
    public void Eliminar(JTable tablaLibros, JTextField codigoLibro) {

        //Eliminaci�n visual de la tabla
        DefaultTableModel model = (DefaultTableModel) tablaLibros.getModel();

        for (int i = 0; i < model.getRowCount(); i++)
        {

            if (((String) model.getValueAt(i, 0)).equals(codigoLibro.getText()))
            {
                model.removeRow(i);
                break;

            }
        }
        //Limpieza del archivo .txt

        try
        {
            PrintWriter writer = new PrintWriter("AudioLibro.txt");
            writer.print("");
            writer.close();
        } catch (FileNotFoundException e)
        {
            JOptionPane.showMessageDialog(null, "Ocurrio un problema" + e.toString());
        }

        //Creaci�n de los nuevos registros luego de la eliminaci�n
        try ( BufferedWriter bw = new BufferedWriter(new FileWriter(new File("AudioLibro.txt"))))
        {
            StringJoiner joiner = new StringJoiner(",");

            for (int col = 0; col < tablaLibros.getColumnCount(); col++)
            {
                joiner.add(tablaLibros.getColumnName(col));
            }

            System.out.println(joiner.toString());
            bw.write(joiner.toString());
            bw.newLine();

            for (int row = 0; row < tablaLibros.getRowCount(); row++)
            {
                joiner = new StringJoiner(",");
                for (int col = 0; col < tablaLibros.getColumnCount(); col++)
                {

                    Object obj = tablaLibros.getValueAt(row, col);
                    String value = obj == null ? "null" : obj.toString();
                    joiner.add(value);

                }

                bw.write(joiner.toString());
                bw.newLine();
                JOptionPane.showMessageDialog(null, "Se elimino correctamente");
            }

        } catch (Exception e)
        {
            JOptionPane.showMessageDialog(null, "Ocurrio un error");
        }

    }

    public void Editar(JTable tablaLibros) {

        //Limpieza del archivo .txt
        try
        {
            PrintWriter writer = new PrintWriter("AudioLibro.txt");
            writer.print("");
            writer.close();
        } catch (FileNotFoundException e)
        {
            JOptionPane.showMessageDialog(null, "Ocurrio un problema" + e.toString());
        }

        //Creaci�n de los nuevos registros luego de la eliminaci�n
        try ( BufferedWriter bw = new BufferedWriter(new FileWriter(new File("AudioLibro.txt"))))
        {
            StringJoiner joiner = new StringJoiner(",");
            for (int col = 0; col < tablaLibros.getColumnCount(); col++)
            {
                joiner.add(tablaLibros.getColumnName(col));
            }

            System.out.println(joiner.toString());
            bw.write(joiner.toString());
            bw.newLine();

            for (int row = 0; row < tablaLibros.getRowCount(); row++)
            {
                joiner = new StringJoiner(",");
                for (int col = 0; col < tablaLibros.getColumnCount(); col++)
                {

                    Object obj = tablaLibros.getValueAt(row, col);
                    String value = obj == null ? "null" : obj.toString();
                    joiner.add(value);

                }

                System.out.println(joiner.toString());
                bw.write(joiner.toString());
                bw.newLine();
                //JOptionPane.showMessageDialog(null, "Se modifico correctamente");
            }

        } catch (Exception e)
        {
            JOptionPane.showMessageDialog(null, "Ocurrio un error");
        }

    }
}

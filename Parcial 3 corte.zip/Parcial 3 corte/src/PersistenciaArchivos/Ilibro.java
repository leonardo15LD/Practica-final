
package PersistenciaArchivos;

import javax.swing.JTable;
import javax.swing.JTextField;


public interface Ilibro {
    void crearArchivo();
    void agregarRegistros();
    void MostrarTotal(JTable tablaTotalLibros);
    void Eliminar(JTable tablaLibros, JTextField codigoLibro);
}

package Vista;


import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.BevelBorder;
import javax.swing.JButton;
import java.awt.event.ActionEvent;

public class main extends JFrame {

    private JPanel contentPane;

    /**
     * Launch the application.
     * @param args
     */
    public static void main(String[] args) {
        EventQueue.invokeLater(new Runnable() {
            @Override
            public void run() {
                try
                {
                    main frame = new main();
                    frame.setVisible(true);

                } catch (Exception e)
                {
                }
            }
        });
    }

    /**
     * Create the frame.
     */
    public main() {
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setBounds(100, 50, 400, 280);
        contentPane = new JPanel();
        contentPane.setBorder(new BevelBorder(BevelBorder.LOWERED, null, null, null, null));
        setContentPane(contentPane);
        contentPane.setLayout(null);

        JButton btnNewButton_1 = new JButton("Libros");
        btnNewButton_1.addActionListener((ActionEvent e) ->
        {
            GestionLibro objetoDialog = new GestionLibro();
            objetoDialog.setVisible(rootPaneCheckingEnabled);
        });
        btnNewButton_1.setBounds(125, 22, 150, 40);
        contentPane.add(btnNewButton_1);
        //
        JButton btnNewButton_2 = new JButton("AudioLibros");
        btnNewButton_2.addActionListener((ActionEvent e) ->
        {
            GestionAudioLibro objetoDialog = new GestionAudioLibro();
            objetoDialog.setVisible(rootPaneCheckingEnabled);
        });
        btnNewButton_2.setBounds(125, 100, 150, 40);
        contentPane.add(btnNewButton_2);

        JButton btnNewButton_3 = new JButton("Cerrar");
        btnNewButton_3.addActionListener((ActionEvent e) ->
        {
            System.exit(0);
        });
        btnNewButton_3.setBounds(125, 182, 150, 40);
        contentPane.add(btnNewButton_3);
    }
}

package Vista;


import java.awt.BorderLayout;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.border.TitledBorder;
import javax.swing.JTextField;
import javax.swing.JLabel;
import javax.swing.border.EtchedBorder;
import java.awt.Color;
import javax.swing.JTable;
import javax.swing.JScrollPane;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class GestionLibro extends JDialog {

    private final JPanel contentPanel = new JPanel();
    private JTextField txtIdbn;
    private JTextField txtTitulo;
    private JTextField txtAutor;
    private JTextField txtAño;
    private JTextField txtCosto;
    private JTextField txtnPaginas;
    private JTextField txtEdicion;
    private JTable tbListaLibros;

    /**
     * Launch the application.
     */
    public static void main(String[] args) {
        try
        {
            GestionLibro dialog = new GestionLibro();
            dialog.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
            dialog.setVisible(true);

        } catch (Exception e)
        {
            e.printStackTrace();
        }
    }

    /**
     * Create the dialog.
     */
    public GestionLibro() {
        setBounds(100, 100, 750, 500);
        getContentPane().setLayout(new BorderLayout());
        contentPanel.setBorder(new EmptyBorder(5, 5, 5, 5));
        getContentPane().add(contentPanel, BorderLayout.CENTER);
        contentPanel.setLayout(null);
        {
            JPanel panel = new JPanel();
            panel.setLayout(null);
            panel.setBorder(new TitledBorder(new EtchedBorder(EtchedBorder.LOWERED, new Color(255, 255, 255), new Color(160, 160, 160)), "Datos de Libros", TitledBorder.LEADING, TitledBorder.TOP, null, new Color(0, 0, 0)));
            panel.setBounds(10, 55, 239, 380);
            contentPanel.add(panel);
            {
                txtIdbn = new JTextField();
                txtIdbn.setColumns(10);
                txtIdbn.setBounds(132, 24, 86, 20);
                panel.add(txtIdbn);
            }
            {
                JLabel lblNewLabel_3 = new JLabel("Codigo");
                lblNewLabel_3.setBounds(10, 27, 46, 14);
                panel.add(lblNewLabel_3);
            }
            {
                JLabel lblNewLabel_4 = new JLabel("Titulo");
                lblNewLabel_4.setBounds(10, 68, 112, 14);
                panel.add(lblNewLabel_4);
            }
            {
                JLabel lblNewLabel_5 = new JLabel("Autor");
                lblNewLabel_5.setBounds(10, 106, 112, 14);
                panel.add(lblNewLabel_5);
            }
            {
                JLabel lblNewLabel_6 = new JLabel("Año");
                lblNewLabel_6.setBounds(10, 147, 162, 14);
                panel.add(lblNewLabel_6);
            }
            {
                JLabel lblNewLabel_7 = new JLabel("Costo");
                lblNewLabel_7.setBounds(10, 187, 170, 14);
                panel.add(lblNewLabel_7);
            }
            {
                JLabel lblNewLabel_8 = new JLabel("Paginas");
                lblNewLabel_8.setBounds(10, 227, 270, 14);
                panel.add(lblNewLabel_8);
            }
            {
                JLabel lblNewLabel_9 = new JLabel("Edicion");
                lblNewLabel_9.setBounds(10, 267, 330, 14);
                panel.add(lblNewLabel_9);
            }
            {
                txtTitulo = new JTextField();
                txtTitulo.setColumns(10);
                txtTitulo.setBounds(132, 65, 86, 20);
                panel.add(txtTitulo);
            }
            {
                txtAutor = new JTextField();
                txtAutor.setColumns(10);
                txtAutor.setBounds(132, 103, 86, 20);
                panel.add(txtAutor);
            }
            {
                txtAño = new JTextField();
                txtAño.setBounds(132, 147, 92, 20);
                txtAño.setColumns(10);
                panel.add(txtAño);
            }
            {
                txtCosto = new JTextField();
                txtCosto.setBounds(132, 188, 92, 20);
                txtCosto.setColumns(10);
                panel.add(txtCosto);
            }
            {
                txtnPaginas = new JTextField();
                txtnPaginas.setBounds(132, 229, 92, 20);
                txtnPaginas.setColumns(10);
                panel.add(txtnPaginas);
            }
            {
                txtnPaginas = new JTextField();
                txtnPaginas.setBounds(132, 270, 92, 20);
                txtnPaginas.setColumns(10);
                panel.add(txtnPaginas);
            }
            {
                txtEdicion = new JTextField();
                txtEdicion.setBounds(132, 270, 92, 20);
                txtEdicion.setColumns(10);
                panel.add(txtEdicion);
            }
            {
                JButton btnGuardar = new JButton("Guardar");
                btnGuardar.addActionListener(new ActionListener() {
                    public void actionPerformed(ActionEvent e) {
                        PersistenciaArchivos.Libro objetoLibro = new PersistenciaArchivos.Libro();
                        objetoLibro.setIdbn(txtIdbn.getText());
                        objetoLibro.setTitulo(txtTitulo.getText());
                        objetoLibro.setAutor(txtAutor.getText());
                        objetoLibro.setAnio(txtAño.toString());
                        objetoLibro.setCosto(txtCosto.getText());
                        objetoLibro.setnPaginas(txtnPaginas.toString());
                        objetoLibro.setEdicion(txtEdicion.toString());
                        objetoLibro.agregarRegistros();
                    }
                });
                btnGuardar.setBounds(10, 307, 95, 23);
                panel.add(btnGuardar);
            }
            {
                JButton btnEditar = new JButton("Editar");
                btnEditar.addActionListener(new ActionListener() {
                    public void actionPerformed(ActionEvent e) {
                        PersistenciaArchivos.Libro objetoLibro = new PersistenciaArchivos.Libro();
                        objetoLibro.Editar(tbListaLibros);
                    }
                });
                btnEditar.setBounds(130, 307, 90, 23);
                panel.add(btnEditar);
            }
            {
                JButton btnEliminar = new JButton("Eliminar");
                btnEliminar.addActionListener(new ActionListener() {
                    public void actionPerformed(ActionEvent e) {
                        PersistenciaArchivos.Libro objetoLibro = new PersistenciaArchivos.Libro();
                        objetoLibro.Eliminar(tbListaLibros, txtIdbn);
                    }
                });
                btnEliminar.setBounds(10, 347, 215, 23);
                panel.add(btnEliminar);
            }
           
        }
        {
            JPanel panel_1 = new JPanel();
            panel_1.setLayout(null);
            panel_1.setBorder(new TitledBorder(new EtchedBorder(EtchedBorder.LOWERED, new Color(255, 255, 255), new Color(160, 160, 160)), "Lista de Libros", TitledBorder.LEADING, TitledBorder.TOP, null, new Color(0, 0, 0)));
            panel_1.setBounds(259, 55, 450, 380);
            contentPanel.add(panel_1);
            {
                JScrollPane scrollPane = new JScrollPane();
                scrollPane.setBounds(10, 23, 430, 340);
                panel_1.add(scrollPane);
                {
                    tbListaLibros = new JTable();
                    scrollPane.setViewportView(tbListaLibros);
                }
            }
        }
        {
            JButton btnCrearArchivo = new JButton("Crear Archivo ");
            btnCrearArchivo.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent e) {
                    PersistenciaArchivos.Libro objetoLibro = new PersistenciaArchivos.Libro();
                    objetoLibro.crearArchivo();
                }
            });
            btnCrearArchivo.setBounds(10, 21, 232, 23);
            contentPanel.add(btnCrearArchivo);
        }
        {
            JButton btnMostrar = new JButton("Mostrar Lista de Libros");
            btnMostrar.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent e) {
                    PersistenciaArchivos.Libro objetoLibro = new PersistenciaArchivos.Libro();
                    objetoLibro.MostrarTotal(tbListaLibros);
                }
            });
            btnMostrar.setBounds(261, 21, 134, 23);
            contentPanel.add(btnMostrar);
        }
        {
            JButton btnSeleccionar = new JButton("Seleccionar");
            btnSeleccionar.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent e) {
                    PersistenciaArchivos.Libro objetoLibro = new PersistenciaArchivos.Libro();

                    objetoLibro.seleccionar(tbListaLibros);
                    txtIdbn.setText(objetoLibro.getIdbn());
                    txtTitulo.setText(objetoLibro.getTitulo());
                    txtAutor.setText(objetoLibro.getAutor());
                    txtAño.setText(objetoLibro.getAnio());
                    txtCosto.setText(objetoLibro.getCosto());
                    txtnPaginas.setText(objetoLibro.getnPaginas());
                    txtEdicion.setText(objetoLibro.getEdicion());
                }
            });
            btnSeleccionar.setBounds(555, 21, 150, 23);
            contentPanel.add(btnSeleccionar);
        }
    }

}

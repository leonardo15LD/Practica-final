package Vista;


public class Index {

	public static void main(String[] args) {
		main objetoFrame = new main();
		objetoFrame.setVisible(true);;
	}

}
